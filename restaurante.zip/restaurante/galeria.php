<?php 
include 'templates/cabecera.html'
?>

<div class="row border-bottom bd-lightGray m-3">
    <div class="cell-md-12 d-flex flex-align-center">
        <h2 class="dashboard-section-title text-center text-Center-md w-100">Galería</h3>
    </div>
</div>

<div class="m-3">
    <div class="row">
        <div class="img-container drop-shadow cell-md-3 mt-3">
            <img src="imgs/1.jpg">
        </div>
        <div class="img-container drop-shadow cell-md-3 mt-3">
            <img src="imgs/2.jpg">
        </div>
        <div class="img-container drop-shadow cell-md-3 mt-3">
            <img src="imgs/3.jpg">
        </div>
        <div class="img-container drop-shadow cell-md-3 mt-3">
            <img src="imgs/4.jpg">
        </div>
        <div class="img-container drop-shadow cell-md-3 mt-3">
            <img src="imgs/5.jpg">
        </div>
    </div
></div>












<?php 
include 'templates/footer.html'
?>